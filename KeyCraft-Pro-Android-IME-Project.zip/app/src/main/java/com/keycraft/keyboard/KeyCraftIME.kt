package com.keycraft.keyboard

import android.annotation.SuppressLint
import android.content.Context
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient

class KeyCraftIME : InputMethodService() {
    private var keyboardWebView: WebView? = null
    private var vibrator: Vibrator? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreateInputView(): View {
        vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        val webView = WebView(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (resources.displayMetrics.density * 280).toInt()
            )
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                cacheMode = WebSettings.LOAD_DEFAULT
            }
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
            addJavascriptInterface(AndroidKeyboardBridge(), "AndroidIME")
            loadUrl("https://ais-dev-636flwo2yndhmd3rpskjxi-521423294803.asia-east1.run.app")
        }
        keyboardWebView = webView
        return webView
    }

    inner class AndroidKeyboardBridge {
        @JavascriptInterface
        fun commitText(text: String) {
            currentInputConnection?.commitText(text, 1)
        }
        @JavascriptInterface
        fun deleteBackward() {
            currentInputConnection?.deleteSurroundingText(1, 0)
        }
        @JavascriptInterface
        fun sendEnter() {
            currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        }
        @JavascriptInterface
        fun moveCursor(direction: String) {
            val keyCode = if (direction == "left") KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT
            currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
            currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
        }
        @JavascriptInterface
        fun executeShortcut(shortcut: String) {
            when (shortcut.lowercase()) {
                "a" -> currentInputConnection?.performContextMenuAction(android.R.id.selectAll)
                "c" -> currentInputConnection?.performContextMenuAction(android.R.id.copy)
                "v" -> currentInputConnection?.performContextMenuAction(android.R.id.paste)
                "x" -> currentInputConnection?.performContextMenuAction(android.R.id.cut)
            }
        }
    }
}
